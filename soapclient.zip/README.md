# sample-quickstart
Sample Quickstart

# Observação:
Se houver Exceptions na execução do plugin com o Java 8, tentar a seguinte solução:
Criar um arquivo 'jaxp.properties' sob o diretório <jdk8>/jre/lib com o conteúdo:
javax.xml.accessExternalSchema = all